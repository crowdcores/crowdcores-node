# CrowdCores Node 

Learn more about [CrowdCores on the official website](https://www.crowdcores.com)

To run a CrowdCores Node install the package:

```
pip3 install crowdcores_node
```

Start your CrowdCore Node Server by running:

```
crowdcores_node
```



